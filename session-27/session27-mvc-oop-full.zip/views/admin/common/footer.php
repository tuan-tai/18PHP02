
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="public/js/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="public/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="public/js/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="public/js/raphael.min.js"></script>
    <script src="public/js/morris.min.js"></script>
    <script src="public/js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="public/js/sb-admin-2.min.js"></script>

</body>

</html>