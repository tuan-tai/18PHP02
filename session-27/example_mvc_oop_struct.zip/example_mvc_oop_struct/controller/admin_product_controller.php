<?php 
include './model/user_model.php';
class AdminProductController{
	//backend
	function add(){

	}
	function edit(){
		
	}
	function delete(){
		
	}
}
?>