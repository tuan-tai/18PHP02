<?php 
include './model/user_model.php';
class ProductController{
	//frontend
	function detail(){
		
	}
	function list(){
		
	}
	function buy(){
		
	}
}
?>