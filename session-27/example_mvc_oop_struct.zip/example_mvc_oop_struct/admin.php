Backend
<a href="admin.php">Dashboard</a>
| <a href="admin.php?controller=admin_product&action=list">Manage product</a>
| <a href="admin.php?controller=admin_news&action=list">Manage news</a>