<?php 

?>
<a href="index.php">Home</a>
| <a href="index.php?controller=product&action=list">List product</a>
| <a href="index.php?controller=news&action=list">List news</a>


<!-- 
12 action:
- list_product
- add_product
- edit_product
- delete_product
- list_news
- add_news
- edit_news
- delete_news
- list_contact
- add_contact
- edit_contact
- delete_contact
- thank_contact

3 controller
- product
- news
- contact
4 action
- list
- add
- edit
- delete
- thank
product + list
product + add
product + edit
product + delete
news + list
news + add
news + edit
news + delete
contact + list
contact + add
contact + edit
contact + delete
contact + thank
 -->
Frontend