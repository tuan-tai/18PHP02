<?php 
echo $about;
?>