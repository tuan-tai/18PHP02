<?php 
echo $news;
?>