<?php 
echo $contact;
?>