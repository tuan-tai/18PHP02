<?php 
echo $home;
?>