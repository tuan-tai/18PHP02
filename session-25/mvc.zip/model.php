<?php 
class ExModel{
	function getHome(){
		return  "Lay thong tin trang chu tu database va tra ve cho model <br/>";
	}
	function getNews(){
		return "Lay thong tin trang news tu database va tra ve cho model <br/>";
	}
	function getContact(){
		return  "Lay thong tin trang contact tu database va tra ve cho model <br/>";
	}
	function getAbout(){
		return  "Lay thong tin trang about tu database va tra ve cho model <br/>";
	}
}
?>