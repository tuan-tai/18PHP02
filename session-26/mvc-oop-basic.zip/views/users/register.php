<h1>Register form</h1>
<form action="" method="post">
	<p>Email<input type="text" name="email"></p>
	<p><input type="submit" name="register" value="Register"></p>
</form>